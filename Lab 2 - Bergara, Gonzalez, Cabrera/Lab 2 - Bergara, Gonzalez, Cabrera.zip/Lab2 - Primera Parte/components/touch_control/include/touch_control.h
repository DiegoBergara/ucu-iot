#include <stdbool.h>

void touch_init(void);

bool play_pause_button_pressed(void);

bool record_button_pressed(void);

bool vol_up_button_pressed(void);

bool vol_down_button_pressed(void);

bool guard_button_pressed(void);
