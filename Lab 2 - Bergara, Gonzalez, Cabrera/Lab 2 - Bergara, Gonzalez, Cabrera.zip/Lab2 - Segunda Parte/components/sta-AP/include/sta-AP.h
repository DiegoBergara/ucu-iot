void createAp(void);

void createSTA(void);

void setMode(int mode);
