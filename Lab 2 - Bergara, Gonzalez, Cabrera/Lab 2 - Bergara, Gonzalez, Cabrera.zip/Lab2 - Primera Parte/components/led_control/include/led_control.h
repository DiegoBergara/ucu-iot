#include "led_strip.h"

void led_init();

void set_color(uint32_t red, uint32_t green, uint32_t blue);