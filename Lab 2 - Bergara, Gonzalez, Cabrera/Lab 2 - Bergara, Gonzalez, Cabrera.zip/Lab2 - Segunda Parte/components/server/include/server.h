void server_init();
